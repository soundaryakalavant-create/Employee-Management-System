package com.employee.management.controller;

import com.employee.management.model.Employee;
import com.employee.management.repository.EmployeeRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    private final EmployeeRepository employeeRepository;

    public EmployeeController(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @GetMapping
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    @GetMapping("/{code}")
    public ResponseEntity<?> getEmployee(@PathVariable String code) {
        return employeeRepository.findByCode(code)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(Map.of("message", "Employee not found")));
    }

    @PostMapping
    public ResponseEntity<?> createEmployee(@RequestBody Employee employee) {
        if (employee.getCode() == null || employee.getCode().isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Employee code is required"));
        }

        if (employeeRepository.existsByCode(employee.getCode())) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("message", "Employee code already exists"));
        }

        return ResponseEntity.status(HttpStatus.CREATED).body(employeeRepository.save(employee));
    }

    @PutMapping("/{code}")
    public ResponseEntity<?> updateEmployee(
            @PathVariable String code,
            @RequestBody Employee updated) {

        return employeeRepository.findByCode(code).map(employee -> {
            employee.setCode(updated.getCode());
            employee.setEmployeeName(updated.getEmployeeName());
            employee.setDateOfBirth(updated.getDateOfBirth());
            employee.setEmailAddress(updated.getEmailAddress());
            employee.setAddress1(updated.getAddress1());
            employee.setAddress2(updated.getAddress2());
            employee.setCity(updated.getCity());
            employee.setState(updated.getState());
            employee.setPhoneNumber(updated.getPhoneNumber());
            employee.setEmergencyNumber(updated.getEmergencyNumber());
            employee.setPanNumber(updated.getPanNumber());
            employee.setTaxStatus(updated.getTaxStatus());
            employee.setGender(updated.getGender());

            return ResponseEntity.ok(employeeRepository.save(employee));
        }).orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(Map.of("message", "Employee not found")));
    }

    @DeleteMapping("/{code}")
    public ResponseEntity<?> deleteEmployee(@PathVariable String code) {
        return employeeRepository.findByCode(code).map(employee -> {
            employeeRepository.delete(employee);
            return ResponseEntity.ok(Map.of("message", "Employee deleted successfully"));
        }).orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(Map.of("message", "Employee not found")));
    }
}
